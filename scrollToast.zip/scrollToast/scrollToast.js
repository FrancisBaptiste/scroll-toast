
(function($, window, document, undefined){

	$.fn.extend({
		scrollToast: function(options, more){


			//var options = $.extend(defaults, options);

			return this.each(function(){

		var el = document.getElementById(options);		

		var elPos = $(el).offset();	
		
		$(el).bind('click', function(){
			alert(elPos.top);
		});	

		var screenHeight = window.innerHeight;
		var currentScrollPos = document.body.scrollTop;
		var easeRate = 8;

		$(window).scroll(function(){
			currentScrollPos = $(document).scrollTop();
		});

		$(window).resize(function(){
			screenHeight = window.innerHeight;
		});

		function scrollToPos(thisPos){
			var i = 1;
			var myInterval = setInterval(function(){
				var dist = thisPos - currentScrollPos;
				var nextPos = currentScrollPos + ((dist+i)/easeRate);
				window.scrollTo(0, nextPos);
				if(Math.abs(thisPos-nextPos) <= 2){
					window.scrollTo(0, thisPos);
					clearInterval(myInterval);
					$("#done").html('done');
				}
				i++;
			}, 33);		
		}

		$(this).bind('click', function(){
			scrollToPos(elPos.top);
		});

			});
		}

	});	


}) (jQuery, window, document);